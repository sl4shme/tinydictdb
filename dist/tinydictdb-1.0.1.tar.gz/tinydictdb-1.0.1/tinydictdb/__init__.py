try:
    from tinydictdb import TinyDictDb
    from prettyprinter import PrettyPrinter
except:
    from tinydictdb.tinydictdb import TinyDictDb
    from tinydictdb.prettyprinter import PrettyPrinter
